/**
 * 静态数组实现栈
 */
#include<stdio.h>
#include<stddef.h>
#include<stdlib.h>
#define MAXN 10001
typedef struct Stack{
    int array[MAXN];
    int top;
}Stack;

void init(Stack* st){
    st->top = 0;
}

void push(Stack *st, int val){
    if(st->top>MAXN){
        printf("Stack OverFlow!\n");
        return ;
    }
    st->array[st->top++]=val;
}

void pop(Stack* st){
    if(st->top==0){
        printf("Stack DownFlow\n");
        exit(-1);
    }
    st->top--;
}

int top(Stack* st){
    if(st->top==0){
        printf("Stack DownFlow\n");
        exit(-1);
    }
    return st->array[st->top-1];
}

/**
测试开始
入栈序列:1 2 3 4
出栈序列:
4
3
2
1
测试结束
 */
int main(){
    printf("测试开始\n");
    printf("入栈序列:1 2 3 4\n");
    Stack stack;
    init(&stack);
    //输入序列[1,2,3,4]
    push(&stack, 1);
    push(&stack, 2);
    push(&stack, 3);
    push(&stack, 4);

    printf("出栈序列:\n");
    while(stack.top!=0){
        printf("%d\n",top(&stack));
        pop(&stack);
    }
    printf("测试结束\n");
    return 0;
}
