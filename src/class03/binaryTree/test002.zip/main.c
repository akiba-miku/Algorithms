#include <stdio.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>

#define MAXN 10001

typedef struct node {
    char data; // 节点的数据
    struct node *Lchild, *Rchild; // 左右子节点指针
} BiTNode, *BiTree;

// 队列定义及辅助变量
BiTNode* queue[MAXN];
int l, r; // 队列的头尾指针

// 队列初始化
void init() {
    l = r = 0; // 初始化队列头尾指针
}

// 判断队列是否为空
bool empty() {
    return l == r;
}

// 层序遍历统计二度节点的函数
int count(BiTree root) {
    // 如果树为空，直接返回 0
    if (root == NULL) {
        return 0;
    }

    int cnt = 0; // 计数二度节点
    init(); // 初始化队列
    queue[r++] = root; // 将根节点入队

    while (!empty()) {
        BiTNode* cur = queue[l++]; // 队头出队

        // 判断当前节点是否为二度节点（有左右子节点）
        if (cur->Lchild != NULL && cur->Rchild != NULL) {
            ++cnt;
        }

        // 将左右子节点入队（如果存在）
        if (cur->Lchild != NULL) {
            queue[r++] = cur->Lchild;
        }
        if (cur->Rchild != NULL) {
            queue[r++] = cur->Rchild;
        }
    }

    return cnt; // 返回二度节点的数量
}

// 二叉树创建函数
BiTree createExampleTree() {
    // 分配节点
    BiTNode* root = (BiTNode*)malloc(sizeof(BiTNode));
    BiTNode* node1 = (BiTNode*)malloc(sizeof(BiTNode));
    BiTNode* node2 = (BiTNode*)malloc(sizeof(BiTNode));
    BiTNode* node3 = (BiTNode*)malloc(sizeof(BiTNode));
    BiTNode* node4 = (BiTNode*)malloc(sizeof(BiTNode));

    // 初始化节点
    root->data = 'A'; root->Lchild = node1; root->Rchild = node2;
    node1->data = 'B'; node1->Lchild = node3; node1->Rchild = node4;
    node2->data = 'C'; node2->Lchild = NULL; node2->Rchild = NULL;
    node3->data = 'D'; node3->Lchild = NULL; node3->Rchild = NULL;
    node4->data = 'E'; node4->Lchild = NULL; node4->Rchild = NULL;

    return root; // 返回树的根节点
}

// 主函数进行测试
int main() {
    // 创建一个示例二叉树
    BiTree root = createExampleTree();

    // 统计二度节点数量
    int result = count(root);
    printf("二叉树中二度节点的数量: %d\n", result);

    // 释放分配的内存（简单释放）
    free(root->Lchild->Lchild); // 释放 D
    free(root->Lchild->Rchild); // 释放 E
    free(root->Lchild);         // 释放 B
    free(root->Rchild);         // 释放 C
    free(root);                 // 释放 A

    return 0;
}
